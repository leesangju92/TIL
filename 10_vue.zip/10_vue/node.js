const aaa = require("fortest/myfirstpubbbbbb");

console.log(aaa.name);


// global

// process

//
global.console.log(process.env);