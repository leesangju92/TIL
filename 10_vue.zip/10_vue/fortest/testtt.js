const LSJ = require("myfirstpubbbbbb");

console.log(LSJ.utility.name);

console.log(LSJ.utility.addAll([1,2,3,4]));